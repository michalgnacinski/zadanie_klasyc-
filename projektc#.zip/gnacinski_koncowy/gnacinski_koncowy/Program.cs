﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
internal class Program
{
    public class Book //utworzenie głównej klasy książka
{
    public string Tytul {  get; set; }
    public string Gatunek {  get; set; }
    public string Autor { get; set; }
    public int NumerIndeksu {  get; set; }

    public Book(string tytul, string gatunek, string autor, int numerIndeksu) //obiekt Book zczytujący wartosci
    {
        Tytul = tytul;
        Gatunek = gatunek;
        Autor = autor;
        NumerIndeksu = numerIndeksu;
    }
    public virtual void WypiszKsiążke() //metoda virtual wypisujaca
    {
        Console.WriteLine("Tytuł: {0}",Tytul);
        Console.WriteLine("Gatunek: {0}", Gatunek);
        Console.WriteLine("Autor: {0}", Autor);
        Console.WriteLine("Numer indeksu: {0}", NumerIndeksu);
    }
    public virtual void WypiszAll()
    {

    }
}
    public interface IKsiazka //utworzenie interfejsu
    {
        string Tytul { get; set; }
        string Gatunek { get; set; }
        string Autor { get; set; }
        int NumerIndeksu { get; set; }

        void WypiszKsiazke();
        void WypiszAll();
    }

    class Autor // klasa autor
{
    public string ImieAutora {  get; set; }
    public string NazwiskoAutora { get; set; }
    public string Epoka { get; set; }
    public string Narodowosc { get; set; }

    public Autor(string imieAutora, string nazwiskoAutora, string epoka, string narodowosc) // obiekt Autor zczytujący właściwości
    {
        ImieAutora = imieAutora;
        NazwiskoAutora = nazwiskoAutora;
        Epoka = epoka;
        Narodowosc = narodowosc;
    }
    public virtual void WypiszAutor() //metoda cirtual wypisujaca
    {
        Console.WriteLine("Imię: {0}", ImieAutora);
        Console.WriteLine("Nazwisko: {0}", NazwiskoAutora);
        Console.WriteLine("Epoka: {0}", Epoka);
        Console.WriteLine("Narodowość: {0}", Narodowosc);
    }
}
public class Liryka : Book //utworzenie klasy potomnej
{
    public string Poeta {  get; set; }

    public Liryka(string tytul, string gatunek, string autor, int numerIndeksu, string poeta) : base(tytul, gatunek,  autor, numerIndeksu) // obiekt odowlujacy sie do bazowej klasy
    {
        Poeta = poeta;
    }
    public virtual void WypiszKsiążke() //metoda virtual wypisujaca
    {
        Console.WriteLine("Tytuł: {0}", Tytul);
        Console.WriteLine("Gatunek: {0}", Gatunek);
        Console.WriteLine("Autor: {0}", Autor);
        Console.WriteLine("Numer indeksu: {0}", NumerIndeksu);
        Console.WriteLine("Poeta: {0} ", Poeta);
    }
    public override void WypiszAll()
    {
        Console.WriteLine("Twórcą jest Poeta");
    }
}
public class Dramat : Book //utworzenie klasy potomnej
{
    public string Rezyser { get; set; }

    public Dramat(string tytul, string gatunek, string autor, int numerIndeksu, string rezyser) : base(tytul, gatunek, autor, numerIndeksu) // obiekt odowlujacy sie do bazowej klasy
    {
        Rezyser = rezyser;
    }
    public virtual void WypiszKsiążke() //metoda virtual wypisujaca
    {
        Console.WriteLine("Tytuł: {0}", Tytul);
        Console.WriteLine("Gatunek: {0}", Gatunek);
        Console.WriteLine("Autor: {0}", Autor);
        Console.WriteLine("Numer indeksu: {0}", NumerIndeksu);
        Console.WriteLine("Poeta: {0} ", Rezyser);
    }
    public override void WypiszAll()
    {
        Console.WriteLine("Twórcą jest Reżyser");
    }
}

public class Epika : Book //utworzenie klasy potomnej
{
    public string Author { get; set; }

    public Epika(string tytul, string gatunek, string autor, int numerIndeksu, string author) : base(tytul, gatunek, autor, numerIndeksu) // obiekt odowlujacy sie do bazowej klasy
    {
        Author = author;
    }
    public virtual void WypiszKsiążke() //metoda virtual wypisujaca
    {
        Console.WriteLine("Tytuł: {0}", Tytul);
        Console.WriteLine("Gatunek: {0}", Gatunek);
        Console.WriteLine("Autor: {0}", Autor);
        Console.WriteLine("Numer indeksu: {0}", NumerIndeksu);
        Console.WriteLine("Poeta: {0} ", Author);
    }
    public override void WypiszAll()
    {
        Console.WriteLine("Twórcą jest Autor");
    }
}


public class WypozyczenieKsiazek //utowrzneie nowej klasy sluzacej do wypozyczania ksiazek
{
    private List<Book> ksiazki; //stworzenie listy
   
    public WypozyczenieKsiazek() //obiekt przechowujacy nowy obiekt
    {
        ksiazki = new List<Book>();
    }
    public void DodajDoDostepnych(Book book) //metoda dodajacxa ksiązke do listy dostepnych
    {
        ksiazki.Add(book);
        Console.WriteLine("Dodano do książek dostępnych {0} napisaną przez {1} o indeksie {2}", book.Tytul, book.Autor,book.NumerIndeksu);
    }
    public void PokazDostepneKsiazki() //metoda pokazująca wszystkier dostępne ksiazki
    {
        Console.WriteLine("Dostępne ksiązki:");
        foreach(var book in ksiazki)
        {
            Console.WriteLine("{0}. {1} nr. {2}",book.Tytul,book.Autor,book.NumerIndeksu);
        }
    }
    public void WypozyczKsiazke(Book book) //metoda wypozyczajaca ksiazki
    {
        Book wypozyczKsiazke = null;

        foreach (var availableBook in ksiazki)
        {
            if (availableBook.NumerIndeksu == book.NumerIndeksu)
            {
                wypozyczKsiazke = availableBook;
                break;
            }
        }

        if (wypozyczKsiazke != null)
        {
            Console.WriteLine("Wypożyczasz książkę {0} napisaną przez {1} o numerze {2}", wypozyczKsiazke.Tytul, wypozyczKsiazke.Autor, wypozyczKsiazke.NumerIndeksu);
            ksiazki.Remove(wypozyczKsiazke);
        }
        else
        {
            Console.WriteLine("Książka o podanym numerze indeksu nie istnieje.");
        }
    }

}

    private static void Main(string[] args)
    {
        WypozyczenieKsiazek biblioteka = new WypozyczenieKsiazek();

        Book b1 = new Book("Antygona", "Epika", "Sofokles", 2); //dodanie nowego elementu Book
        Book b2 = new Book("Lalka", "Epika", "Prus", 9); //dodanie nowego elementu Book
        biblioteka.DodajDoDostepnych(b1); //wywołanie metody dla elementu b1
        biblioteka.DodajDoDostepnych(b2 ); //wywołanie metody dla elementu b2
        biblioteka.PokazDostepneKsiazki(); //wywołanie metody wypisujacej
        Console.WriteLine();
        Autor a1 = new Autor("Adam", "Mickiewicz", "romantyzm", "Polska"); //dodanie nowego elementu Autor
        a1.WypiszAutor(); //wypisywanie autra
        Console.WriteLine();
        biblioteka.WypozyczKsiazke(b1 ); //wywołanie metody dla b1
        biblioteka.PokazDostepneKsiazki(); //wypisywanie dostepnych ksiazek
        Console.WriteLine();
        List<Book> list = new List<Book>() //utworzenie nowej listy
        {
        new Liryka("Oda do młodości", "Liryka", "Adam Mickiewicz", 1, "Adam Mickiewicz"), //dodanie elementu do listy
        new Dramat("Hamlet", "Dramat", "William Shakespeare", 2, "Reżyser"), //dodanie elementu do listy
        new Epika("Quo Vadis", "Epika", "Henryk Sienkiewicz", 3, "Autor") //dodanie elementu do listy
        };
        foreach(var bo in list) //wypisanie metody za pomoca petli
        {
            bo.WypiszAll();
        }

        Dictionary<string, Book> dictionary = new Dictionary<string, Book>(); //utworzenie slownika
        foreach (var book in list)
        {
            dictionary.Add(book.Tytul, book); //wypisanie wszystkich ksiazek ze slownika
        }

        
        string sciezkaPliku = @"c:\pliki\plik.txt"; // scieżka do pliku z danymi

        
        List<Book> listaKsiazek = new List<Book>(); // lista do przechowywania odczytanych książek

        if (File.Exists(sciezkaPliku))
        {
            try
            {
                
                using (StreamReader sr = new StreamReader(sciezkaPliku)) // otwarcie pliku do odczytu
                {
                    string linia;

                    while ((linia = sr.ReadLine()) != null) //odczytanie pliku do konca
                    {
                        string[] daneKsiazki = linia.Split(';'); //rozdzielenie pliku 

                        if (daneKsiazki.Length == 4)
                        {
                            //zmiana danych
                            string tytul = daneKsiazki[0];
                            string gatunek = daneKsiazki[1];
                            string autor = daneKsiazki[2];
                            int numerIndeksu = int.Parse(daneKsiazki[3]);

                           
                            Book ksiazka = new Book(tytul, gatunek, autor, numerIndeksu); // utworzenie obiektu książki i dodanie do listy
                            listaKsiazek.Add(ksiazka); 
                        }
                        else
                        {
                            Console.WriteLine("Niepoprawny format danych w pliku.");
                        }
                    }
                }
                //Obsługa błędów
                // Wyświetlenie odczytanych książek
                foreach (var ksiazka in listaKsiazek)
                {
                    Console.WriteLine($"Tytuł: {ksiazka.Tytul}, Gatunek: {ksiazka.Gatunek}, Autor: {ksiazka.Autor}, Numer Indeksu: {ksiazka.NumerIndeksu}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd odczytu pliku: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("Plik z danymi nie istnieje.");
        }
    }


}
