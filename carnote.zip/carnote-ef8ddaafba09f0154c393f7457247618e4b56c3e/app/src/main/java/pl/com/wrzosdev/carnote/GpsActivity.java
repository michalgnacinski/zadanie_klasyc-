package pl.com.wrzosdev.carnote;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * Aktywność liczenia czasu potrzebnego na rozpędzenie auta do setki
 */

public class GpsActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //todo ustawić widok okna
        //zainicjalizujemy tu pola
        //zainicjalizujemy widoki
        if (savedInstanceState != null)
        {
            //tu odzyskac ostatnie odczyty z okna po ubiciu
        }

    }

    @Override
    protected void onResume()
    {
        super.onResume();
        //podepnij GPS
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        //odepnij GPS
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        //tu zapisać do bundla stan aktualnej pozycji
        //czy też ostatnie odczyty
        super.onSaveInstanceState(outState);
    }
}
