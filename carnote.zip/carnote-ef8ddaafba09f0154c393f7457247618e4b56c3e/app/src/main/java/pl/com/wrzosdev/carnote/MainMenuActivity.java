package pl.com.wrzosdev.carnote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Date;

import pl.com.wrzosdev.carnote.historylist.HistoryAdapter;
import pl.com.wrzosdev.carnote.model.AutoData;
import pl.com.wrzosdev.carnote.model.TankUpRecord;

/**
 * Okno menu głownego
 */
public class MainMenuActivity extends AppCompatActivity
{
    public static final String SPECIAL_DATA = "SPECIAL_DATA";
    public static final int NEW_CAR_REQUEST_CODE = 12346;
    public static final int TANK_REQUEST_CODE = 6754;

    private Button goToTankFormButton;
    private Button goToNewCarButton;
    private Spinner autoChooseSpinner;

    private ArrayList<AutoData> autoList;
    private ArrayAdapter<AutoData> arrayAdapter;
    private RecyclerView historyRecyclerView;
    private RecyclerView.Adapter historyAdapter;
    private RecyclerView.LayoutManager historyLayoutManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu_layout);
        initViews();

    }

    private void initViews()
    {
        goToTankFormButton = (Button) findViewById(R.id.go_to_tank_form_button);
        goToNewCarButton = (Button) findViewById(R.id.new_car_button);
        autoChooseSpinner = (Spinner) findViewById(R.id.auto_choose_spinner);
        historyRecyclerView = (RecyclerView) findViewById(R.id.historyRecyclerView);

        initAutoList();
        initArrayAdapter();
        autoChooseSpinner.setAdapter(arrayAdapter);
        initRecyclerView();

        goToTankFormButton.setOnClickListener(goToTankUpActivity());
        goToNewCarButton.setOnClickListener(goToNewCarActivity());
    }

    private void initRecyclerView()
    {
        historyLayoutManager = new LinearLayoutManager(this);
        historyRecyclerView.setLayoutManager(historyLayoutManager);

        historyRecyclerView.setHasFixedSize(true);

        historyAdapter = new HistoryAdapter(this, getCurrentAuto().getTankUpRecord());
        historyRecyclerView.setAdapter(historyAdapter);
    }

    @NonNull
    private View.OnClickListener goToTankUpActivity()
    {
        return new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainMenuActivity.this, GasTankUpActivity.class);
                intent.putExtra(SPECIAL_DATA, getCurrentAuto());
                startActivityForResult(intent, TANK_REQUEST_CODE);
            }
        };
    }

    private void initArrayAdapter()
    {
        arrayAdapter = new ArrayAdapter<AutoData>(this, android.R.layout.simple_spinner_item, autoList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }

    private void initAutoList()
    {
        autoList = new ArrayList<AutoData>();
        autoList.add(new AutoData("Golf 6", "VolksWagen", "Perłowy metalik"));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 7, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 6, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 5, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 4, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 3, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 2, 10, 50));
        autoList.get(0).getTankUpRecord().add(new TankUpRecord(new Date(), 1, 10, 50));
        autoList.add(new AutoData("Polo 3", "VolksWagen", "Różowy"));
    }

    @NonNull
    private AutoData getCurrentAuto()
    {
        return (AutoData) autoChooseSpinner.getSelectedItem();
    }

    private View.OnClickListener goToNewCarActivity()
    {
        return new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainMenuActivity.this, AddCarActivity.class);
                startActivityForResult(intent, NEW_CAR_REQUEST_CODE);
            }
        };
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == NEW_CAR_REQUEST_CODE)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                if (data != null)
                {
                    AutoData newAutoData = (AutoData) data.getExtras().get(AddCarActivity.AUTO_DATA_NEW_CAR);
                    Boolean isNewCarMasterCar = (Boolean) data.getExtras().get(AddCarActivity.IS_NEW_CAR_MASTER_CAR);
                    if (isNewCarMasterCar != null && isNewCarMasterCar)
                    {
                        autoList.add(0, newAutoData);
                    } else
                    {
                        autoList.add(newAutoData);
                    }
                }
            }
        }
        if (requestCode == TANK_REQUEST_CODE)
        {
            if (resultCode == Activity.RESULT_OK)
            {
                if (data != null)
                {
                    TankUpRecord newTankUp = (TankUpRecord) data.getExtras().get(GasTankUpActivity.NEW_TANKUP_RECORD);
                    if (newTankUp != null)
                    {
                        getCurrentAuto().getTankUpRecord().add(0, newTankUp);
                        historyAdapter.notifyDataSetChanged();
                    }
                }
            }
        }
    }
}
