namespace galeria
{
    public partial class Form1 : Form
    {
        private object pboImage;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string image;
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if(openFileDialog.ShowDialog()== System.Windows.Forms.DialogResult.OK)
                {
                    image = openFileDialog.FileName;
                    pictureBox1.ImageLocation = image;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("error occured");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void oProgramieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult wiad = MessageBox.Show(
                    "Wykona�: Micha� Gnaci�ski", "Galeria"
                );
        }
    }
}