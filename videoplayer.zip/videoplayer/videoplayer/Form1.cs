﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace videoplayer
{
    public partial class Form1 : Form
    {
        string videoPath, videoTitle;
        public Form1()
        {
            InitializeComponent();
            axWindowsMediaPlayer1.uiMode = "none";
        }

        private void play_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void stop_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            
        }

        private void pouse_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.pause();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mute_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.settings.volume = 0;
        }

        private void oProgramieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult alert = MessageBox.Show("VideoPlayer w wykonaniu Michała Gnacińskiego \n Za pomocą programu można otworzyć film pobrany w pliku \n mp3 oraz manipulować nagraniem poprzez zatrzymywanie, wznawianie i wyciszanie", "VideoPlayer");
        }

        private void otworz_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog() { Multiselect = false, Filter = "MP4 File|*.mp4|All File|*.*" };
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                videoPath = openFileDialog.FileName;
                videoTitle = openFileDialog.SafeFileName;
                axWindowsMediaPlayer1.URL = videoPath;
                label1.Text = videoTitle;
            }
        }
    }
}
